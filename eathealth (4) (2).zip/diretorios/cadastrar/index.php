<?php 

	$page_name = "Login";
	require "../config/conn.php";
	require "../config/geral.php";
	require "../config/cdn.php";

	if (isset($_SESSION['admin'])) { echo "<script>window.location.href='./painel'</script>"; }

	if (isset($_POST['user']) && isset($_POST['pass'])) {

		$nome	= $_POST['nome'];
		$user	= $_POST['user'];
		$email	= $_POST['email'];
		$pass	= hash('sha256', $_POST['pass']);

		$sql = "INSERT INTO users (usuario, nome, email, senha) VALUES ('$nome', '$user', '$email', '$pass')";
		if ($conn->query($sql) === TRUE) { 

			$id_cliente = $conn->insert_id;

			$query = "SELECT * FROM users WHERE id = '$id_cliente'";
			$mysqli_query = mysqli_query($conn, $query);
			while ($admin_data = mysqli_fetch_array($mysqli_query)) { $admin = $admin_data; }

			$_SESSION['admin'] = $admin;
			echo '<script>window.location.href="../painel"</script>';

		} else { 
			echo '<script>alert("Erro ao inserir.")</script>';
			echo '<script>window.location.href="./"</script>';
		}

	}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../assets/css/login.css">
</head>
<body>
	<div class="container align">
		<div class="row loginBox">
			<div style="background: url('../assets/img/bg/login.jpg');" class="col-0 col-lg-7 col-xl-8 right">
				<div class="bg"></div>
			</div>
			<div class="col-12 col-lg-5 col-xl-4 left">
				<div class="align">
					<a href="#"><img width="100px" class="logo" src="https://i.ibb.co/28Tmvmb/logo1.png"></a>
					<h1>Cadastrar</h1>
					<p>Insira as suas informações para cadastrar.</p>
					<hr>
					<form method="POST" action="">

						<label class="input">Nome</label><br>
						<input required placeholder="ex: Jhon Doe" type="text" name="nome"><br>
						
						<label class="input">Usuário</label><br>
						<input required placeholder="ex: jhon_doe" type="text" name="user"><br>
						
						<label class="input">E-mail</label><br>
						<input required placeholder="ex: jhon_doe@gmail.com" type="email" name="email"><br>

						<label class="input">Senha:</label><br>
						<input required placeholder="*********" type="password" name="pass"><br>

						<div style="margin-bottom: 15px;" class="row">
							<div class="col-6">
								<div class="align">
									<input checked id="remember" style="width: auto; margin-bottom: 0px;" type="checkbox" name="manter_logado">
									<label class="remember" for="remember">Lembrar senha</label>
								</div>
							</div>
							<div style="text-align: right;" class="col-6">
								<div class="align">

								</div>
							</div>
						</div>

						<button name="entrar" class="entrar">Cadastrar</button>
						<?php if (isset($msg)) { ?><p class="msg"><?php echo $msg; ?></p><?php } ?>
						<a class="register" href="../"><p class="register">Fazer Login</p></a>
					</form>
				</div>
			</div>
		</div>
	</div>
</body>
</html>